
CREATE DATABASE IF NOT EXISTS BookStore;

USE BookStore;


CREATE TABLE IF NOT EXISTS books (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    genre VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 0 AND rating <= 5),  -- Rating between 0 and 5
    copies_sold INT NOT NULL,
    price DOUBLE NOT NULL,
    publisher VARCHAR(255) NOT NULL
);


INSERT INTO books (title, author, genre, rating, copies_sold, price, publisher)
VALUES
    ('Book 1', 'Author 1', 'Fiction', 4, 100, 29.99, 'Publisher1'),
    ('Book 2', 'Author 2', 'Science', 5, 50, 39.99, 'Publisher2'),
    ('Book 3', 'Author 3', 'Fiction', 3, 200, 19.99, 'Publisher1'),
    ('Book 4', 'Author 4', 'History', 4, 150, 49.99, 'Publisher3'),
    ('Book 5', 'Author 5', 'Science', 2, 75, 24.99, 'Publisher2'),
    ('Book 6', 'Author 6', 'Fiction', 5, 300, 59.99, 'Publisher1'),
    ('Book 7', 'Author 7', 'History', 4, 80, 34.99, 'Publisher3');
