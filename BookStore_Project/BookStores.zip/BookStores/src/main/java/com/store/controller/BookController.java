package com.store.controller;

import com.store.model.Book;
import com.store.service.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    // Get books by genre
    @GetMapping("/genre/{genre}")
    public ResponseEntity<List<Book>> getBooksByGenre(@PathVariable String genre) {
        List<Book> books = bookService.getBooksByGenre(genre);
        return ResponseEntity.ok(books);
    }

    // Get top 10 best-sellers
    @GetMapping("/top-sellers")
    public ResponseEntity<List<Book>> getTopSellers() {
        List<Book> books = bookService.getTopSellers();
        return ResponseEntity.ok(books);
    }

    // Get books by rating or higher
    @GetMapping("/rating/{rating}")
    public ResponseEntity<List<Book>> getBooksByRating(@PathVariable int rating) {
        List<Book> books = bookService.getBooksByRating(rating);
        return ResponseEntity.ok(books);
    }

    // Apply discount to books by publisher
    @PutMapping("/discount")
    public ResponseEntity<String> applyDiscountByPublisher(@RequestParam String publisher, @RequestParam double discountPercent) {
        bookService.applyDiscountByPublisher(publisher, discountPercent);
        return ResponseEntity.ok("Discount applied successfully to publisher: " + publisher);
    }
}
