package com.store.service;

import com.store.model.Book;
import com.store.repository.BookRepository;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private static final Logger logger = LoggerFactory.getLogger(BookService.class);

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> getBooksByGenre(String genre) {
        return bookRepository.findByGenre(genre);
    }

    public List<Book> getTopSellers() {
        return bookRepository.findTop10ByOrderByCopiesSoldDesc();
    }

    public List<Book> getBooksByRating(int rating) {
        return bookRepository.findByRatingGreaterThanEqual(rating);
    }

    public void applyDiscountByPublisher(String publisher, double discountPercent) {
        // Validate discount percent
        if (discountPercent < 0 || discountPercent > 100) {
            logger.error("Invalid discount percent: {}. It must be between 0 and 100.", discountPercent);
            throw new IllegalArgumentException("Discount percent must be between 0 and 100.");
        }

        // Find books by publisher
        List<Book> books = bookRepository.findByPublisher(publisher);
        if (books.isEmpty()) {
            logger.warn("No books found for publisher: {}", publisher);
            return;  // Return without any operation if no books are found
        }

        // Apply discount and save the updated prices
        for (Book book : books) {
            double originalPrice = book.getPrice();
            double newPrice = originalPrice * (1 - (discountPercent / 100));
            book.setPrice(newPrice);
            bookRepository.save(book);  // Persist the updated book price
            logger.info("Updated price for book: '{}' from {} to {}", book.getTitle(), originalPrice, newPrice);
        }

        logger.info("Successfully applied {}% discount to all books from publisher: {}", discountPercent, publisher);
    }
}
