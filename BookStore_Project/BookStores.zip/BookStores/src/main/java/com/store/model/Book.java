package com.store.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "books")  // Map to the "books" table in the database
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String author;
    private String genre;
    private int rating;
    private int copiesSold;
    private double price;
    private String publisher;

    // Default constructor
    public Book() {}

    // Parameterized constructor
    public Book(String title, String author, String genre, int rating, int copiesSold, double price, String publisher) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.rating = rating;
        this.copiesSold = copiesSold;
        this.price = price;
        this.publisher = publisher;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }

    public int getCopiesSold() { return copiesSold; }
    public void setCopiesSold(int copiesSold) { this.copiesSold = copiesSold; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", genre='" + genre + '\'' +
                ", rating=" + rating +
                ", copiesSold=" + copiesSold +
                ", price=" + price +
                ", publisher='" + publisher + '\'' +
                '}';
    }
}
